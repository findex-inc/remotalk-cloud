ALTER TABLE department DROP COLUMN deleted;
