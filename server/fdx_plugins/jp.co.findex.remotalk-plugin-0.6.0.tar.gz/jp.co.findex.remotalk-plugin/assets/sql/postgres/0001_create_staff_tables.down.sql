ALTER TABLE staffhospital DROP CONSTRAINT IF EXISTS fk_staffhospital_hospital;
ALTER TABLE staffhospital DROP CONSTRAINT IF EXISTS fk_staffhospital_staffpscid;
DROP TABLE IF EXISTS staffhospital;
DROP TABLE IF EXISTS hospital;

ALTER TABLE staffdepartment DROP CONSTRAINT IF EXISTS fk_staffdepartment_department;
ALTER TABLE staffdepartment DROP CONSTRAINT IF EXISTS fk_staffdepartment_staffpscid;
DROP TABLE IF EXISTS staffdepartment;
DROP TABLE IF EXISTS department;

ALTER TABLE staffprofession DROP CONSTRAINT IF EXISTS fk_staffprofession_profession;
ALTER TABLE staffprofession DROP CONSTRAINT IF EXISTS fk_staffprofession_staffpscid;
DROP TABLE IF EXISTS staffprofession;
DROP TABLE IF EXISTS profession;

ALTER TABLE staffpscid DROP CONSTRAINT IF EXISTS fk_staffpscid_users;
DROP TABLE IF EXISTS staffpscid;
