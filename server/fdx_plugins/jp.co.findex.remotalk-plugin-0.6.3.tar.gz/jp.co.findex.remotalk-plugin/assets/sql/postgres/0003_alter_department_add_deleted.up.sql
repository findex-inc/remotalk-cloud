ALTER TABLE department ADD COLUMN deleted boolean;
