CREATE TABLE IF NOT EXISTS fileaccess
(
    accessid bigint NOT NULL,
    fileid character varying(26) NOT NULL,
    createat bigint,
    CONSTRAINT pk_fileaccess PRIMARY KEY (accessid, fileid),
    CONSTRAINT fk_albumusers_id FOREIGN KEY (accessid)
        REFERENCES albumusers (id) MATCH SIMPLE
        ON UPDATE RESTRICT
        ON DELETE RESTRICT,
    CONSTRAINT fk_savedfiles_fileid FOREIGN KEY (fileid)
        REFERENCES savedfiles (fileid) MATCH SIMPLE
        ON UPDATE RESTRICT
        ON DELETE RESTRICT
);
