CREATE TABLE IF NOT EXISTS teamalbums
(
    teamid character varying(26) NOT NULL,
    maxsize bigint,
    startat bigint,
    endat bigint,
    createat bigint,
    updateat bigint,
    deleteat bigint,
    CONSTRAINT pk_teamalbums PRIMARY KEY (teamid)
);

CREATE TABLE IF NOT EXISTS channelalbums
(
    channelid character varying(26) NOT NULL,
    teamid character varying(26),
    maxsize bigint,
    createat bigint,
    updateat bigint,
    deleteat bigint,
    CONSTRAINT pk_channelalbums PRIMARY KEY (channelid),
    CONSTRAINT fk_teamalbums_teamid FOREIGN KEY (teamid)
        REFERENCES teamalbums (teamid) MATCH SIMPLE
        ON UPDATE RESTRICT
        ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS albumusers
(
    id bigserial NOT NULL,
    userid character varying(26) NOT NULL,
    teamid character varying(26) NOT NULL,
    createat bigint,
    updateat bigint,
    deleteat bigint,
    CONSTRAINT pk_albumusers PRIMARY KEY (id),
    CONSTRAINT fk_teamalbums_teamid FOREIGN KEY (teamid)
        REFERENCES teamalbums (teamid) MATCH SIMPLE
        ON UPDATE RESTRICT
        ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS savedfiles
(
    fileid character varying(26) NOT NULL,
    teamid character varying(26),
    channelid character varying(26),
    path character varying(512),
    name character varying(256),
    extension character varying(64),
    size bigint,
    mimetype character varying(256),
    savedby character varying(26),
    createat bigint,
    updateat bigint,
    deleteat bigint,
    CONSTRAINT pk_savedfiles PRIMARY KEY (fileid),
    CONSTRAINT fk_channelalbums_channelid FOREIGN KEY (channelid)
        REFERENCES channelalbums (channelid) MATCH SIMPLE
        ON UPDATE RESTRICT
        ON DELETE RESTRICT,
    CONSTRAINT fk_teamalbums_teamid FOREIGN KEY (teamid)
        REFERENCES teamalbums (teamid) MATCH SIMPLE
        ON UPDATE RESTRICT
        ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS fileaccess
(
    accessid bigint NOT NULL,
    fileid character varying(26) NOT NULL,
    createat bigint,
    CONSTRAINT pk_fileaccess PRIMARY KEY (accessid, fileid),
    CONSTRAINT fk_albumusers_id FOREIGN KEY (accessid)
        REFERENCES albumusers (id) MATCH SIMPLE
        ON UPDATE RESTRICT
        ON DELETE RESTRICT,
    CONSTRAINT fk_savedfiles_fileid FOREIGN KEY (fileid)
        REFERENCES savedfiles (fileid) MATCH SIMPLE
        ON UPDATE RESTRICT
        ON DELETE RESTRICT
);
