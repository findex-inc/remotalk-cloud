ALTER TABLE IF EXISTS savedfiles ADD COLUMN IF NOT EXISTS postid character varying(26);
