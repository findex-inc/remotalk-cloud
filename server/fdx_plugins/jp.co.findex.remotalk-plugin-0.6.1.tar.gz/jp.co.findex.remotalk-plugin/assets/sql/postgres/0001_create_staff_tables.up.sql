CREATE TABLE IF NOT EXISTS staffpscid (
    pscid integer PRIMARY KEY,
    publicid VARCHAR(20),
    startdatetime bigint,
    enddatetime bigint,
    updatedatetime bigint,
    deleted boolean
);

CREATE TABLE IF NOT EXISTS profession (
    id integer PRIMARY KEY,
    publicid VARCHAR(16),
    name VARCHAR(64),
    category VARCHAR(16),
    updatedatetime bigint
);

CREATE TABLE IF NOT EXISTS staffprofession (
    id integer PRIMARY KEY,
    staffid integer,
    professionid integer,
    startdatetime bigint,
    enddatetime bigint,
    updatedatetime bigint
);

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'fk_staffprofession_staffpscid') THEN
        ALTER TABLE staffprofession
            ADD CONSTRAINT fk_staffprofession_staffpscid
            FOREIGN KEY (staffid) REFERENCES staffpscid (pscid) ON DELETE CASCADE;
    END IF;
END;
$$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'fk_staffprofession_profession') THEN
        ALTER TABLE staffprofession
            ADD CONSTRAINT fk_staffprofession_profession
            FOREIGN KEY (professionid) REFERENCES profession (id) ON DELETE CASCADE;
    END IF;
END;
$$;

CREATE TABLE IF NOT EXISTS department (
    id integer PRIMARY KEY,
    publicid VARCHAR(16),
    name VARCHAR(64),
    shortname VARCHAR(16),
    departmenttype integer,
    sort integer,
    updatedatetime bigint
);

CREATE TABLE IF NOT EXISTS staffdepartment (
    id integer PRIMARY KEY,
    staffid integer,
    departmentid integer,
    maindepartment boolean,
    isadministrator boolean,
    startdatetime bigint,
    enddatetime bigint,
    updatedatetime bigint
);

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'fk_staffdepartment_staffpscid') THEN
        ALTER TABLE staffdepartment
            ADD CONSTRAINT fk_staffdepartment_staffpscid
            FOREIGN KEY (staffid) REFERENCES staffpscid (pscid) ON DELETE CASCADE;
    END IF;
END;
$$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'fk_staffdepartment_department') THEN
        ALTER TABLE staffdepartment
            ADD CONSTRAINT fk_staffdepartment_department
            FOREIGN KEY (departmentid) REFERENCES department (id) ON DELETE CASCADE;
    END IF;
END;
$$;

CREATE TABLE IF NOT EXISTS hospital (
    id integer PRIMARY KEY,
    publicid VARCHAR(16),
    name VARCHAR(64),
    shortname VARCHAR(16),
    sort VARCHAR(16),
    updatedatetime bigint
);

CREATE TABLE IF NOT EXISTS staffhospital (
    id integer PRIMARY KEY,
    staffid integer,
    hospitalid integer,
    updatedatetime bigint
);

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'fk_staffhospital_staffpscid') THEN
        ALTER TABLE staffhospital
            ADD CONSTRAINT fk_staffhospital_staffpscid
            FOREIGN KEY (staffid) REFERENCES staffpscid (pscid) ON DELETE CASCADE;
    END IF;
END;
$$;

DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'fk_staffhospital_hospital') THEN
        ALTER TABLE staffhospital
            ADD CONSTRAINT fk_staffhospital_hospital
            FOREIGN KEY (hospitalid) REFERENCES hospital (id) ON DELETE CASCADE;
    END IF;
END;
$$;
